DESTINATION_BUCKET="<destination_bucket_name>"
DESTINATION_BUCKET_REGION="<destination_bucket_region>"
SIZE=128,128 # Your preferred thumbnail size
